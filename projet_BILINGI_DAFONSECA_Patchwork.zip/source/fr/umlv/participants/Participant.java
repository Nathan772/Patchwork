package fr.umlv.participants;

public interface Participant {
	/**
	 * time field getter.
	 * 
	 * @return time field value
	 */
	default int temps() {
		return this.temps();
	}
	/**
	 * nom field getter.
	 * @return String
	 * the name of the player
	 */
	default String nom() {
		return this.nom();
	}
	
	/**
	 * It's a getter that return a player's age
	 * 
	 * @return int
	 * 
	 * the player age
	 */
		default int age() {
		return age();
	}

}
