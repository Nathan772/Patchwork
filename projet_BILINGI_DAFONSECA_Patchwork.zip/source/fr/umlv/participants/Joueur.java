package fr.umlv.participants;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.swing.text.html.HTMLDocument.Iterator;

import Partie.Partie;
import fr.umlv.outils.*;


/**
 * Declaration of the type "joueur". It is a player who belongs to the Patchwork game.
 * It's handled by a human user
 * 
 * @author Da Fonseca Ayrton Bilingi Nathan
 */

public class Joueur implements Participant {
	

			/* it represents the player board.
			 * The point represents it the coordinate and the integer indicates
			 * with a 0, if it's empty, and 1 if it's filled with a cloth.
			 */
			private HashMap<Point,Integer> plateauP;
			/* this variable represents the player age*/
			private final int age;
			/* it represents the name of the player*/
			private final String nom;
			/* it represents the  leftover time before the end of a player participation*/
			private int temps;
			/* it represent the quantity of button that a player possess at the moment*/
			private int bouton;
			
			/* first constructor for a player */
			public Joueur(int age1, String nom1, Partie p1) {
				Objects.requireNonNull(nom1,"You need a real name not an empty name");
				Objects.requireNonNull(p1, "You can't create a player in an empty party");
				if(age1 < 3)
					throw new IllegalArgumentException("The player can't be younger"
							+ "than '3 years old'. ");
				
				nom = new String(nom1); /* copy profonde du nom du joueur*/
				age = age1;
				temps = p1.temps(); /* on donne au joueur le temps par défaut d'une 
				partie*/
				/* on donne au joueur le nombre de boutons par défaut d'une 
				partie*/
				bouton = p1.bouton();
				
				/* on remplit le plateau avec des emplacements vides par défauts*/
				for(var i=0 ;i<p1.pBoardSize();i++) {
					for(var j=0 ;j<p1.pBoardSize();j++) {
						/* on créé un nouveau espace du plateau pour chaque
						 * emplacement vide. 
						 * On écrit "0" pour indiquer qu'il n'y a pas de tissu*/
						plateauP.put(new Point(i,j), 0);
					}
					
				}
				
				
				
			}
			/* Constructor number 2 overload */
			public Joueur(Joueur j1, Partie p1) {
				this(j1.age, j1.nom,p1);
			}
			@Override
			/**
			 * 
			 * @param o
			 * it's an objects with which one wants to compare a player
			 * @return boolean
			 * it indicates it's the both object are alike or not.
			 * True indicate "yes", False, indicates "no".
			 * 
			 */
			public boolean equals(Object o) {
				Objects.requireNonNull(o,"you can't compare a player with an empty item");
				return o instanceof Joueur j1 && j1.bouton == bouton && j1.age == age
						&& j1.nom.equals(nom) && j1.temps == temps &&
						j1.plateauP.keySet().equals(plateauP.keySet());
			}
			
			@Override
			/**
			 * 
			 * @param o
			 * it's an objects with which one wants to compare a player
			 * @return boolean
			 * it indicates it's the both object are alike or not.
			 * True indicate "yes", False, indicates "no".
			 * 
			 */
			public int hashCode() {
				return Integer.hashCode(age)^nom.hashCode();
			}
			
			@Override
			/**
			 * 
			 * @param o
			 * it's an objects with which one wants to compare a player
			 * @return boolean
			 * it indicates it's the both object are alike or not.
			 * True indicate "yes", False, indicates "no".
			 * 
			 */
			/*/!\  A modifier pour le faire sans le cast *!\ */
			public String toString(){
				var bd = new StringBuilder();
				for(Map.Entry elem : plateauP.entrySet()) { /* fonctionnel mais à revoir car demande un cast*/
					bd.append("case : \n");
					/* on récupère les coordonnées*/
					bd.append(elem.getKey());
					bd.append("\n");
					bd.append("contenu : \n");
					/* on est contraint de "caster" car on à affaire à la valeur du plateau qui est un int*/
					if((int)elem.getValue() == 0) 
						bd.append("vide");
					/* on est contraint de caster car on à affaire à la valeur du plateau qui est un int*/
					else if((int)elem.getValue() == 1)
						bd.append("tissu");
				}
				return "Le nom du joueur : "+nom+ " son âge "+age
						+" son temps restant "+temps
				+ "son nombre de bouton "+bouton+ "l'état de son plateau \n\n\n\n\n\n\n\n : "+bd;
			}
			/**
			 * It's a getter that return a player's age
			 * 
			 * @return int
			 * 
			 * the player age
			 */
			public int age() {
				return age;
			}

	
}
