package fr.umlv.partie;

import java.util.ArrayList;

import fr.umlv.participants.*;

public class Partie {
	/* this it represents the time that will be allowed to each player at the beginning
	 * of the party
	 */
	private final int temps;
	/* this list contains the players that will participate during the party*/
	private ArrayList<Participant> part;
	/* it represents the number of button that a player possess at the beginning of a party*/
	private final int bouton;
	/* it represents the board size*/
	private final int pBoardSize;
	
	/* it's the constructor for a party*/
	public Partie(){
		temps = 50; /*ceci est le temps par défaut: 50*/
		bouton = 50; /* par défaut les joueurs ont 50 bouttons*/
		pBoardSize = 9;/* ceci indique la taille du plateau d'un joueur par défaut 9x9*/
	}
	/**
	 * 
	 * @return int
	 * this value represents the time that will be allowed for each player at the beginning
	 * of the party. It's an accessor.
	 */
	public int temps() {
		return temps;
	}
	
	/**
	 * 
	 * @return int
	 * this value represents the size of a player board.
	 */
	public int pBoardSize() {
		return pBoardSize;
	}
	
	/**
	 * 
	 * @return int
	 * this value represents the bouton that will be allowed for each player at the beginning
	 * of the party. It's an accessor.
	 */
	public int bouton() {
		return bouton;
	}
	/** This method enables to know either a party is over or not
	 * 
	 * @return a int which can be 0 to express the fact that the party keep going
	 * and 1 to express the fact that the party is ended
	 */
	public int finDePartie(){
	  for(var element:part) {
	  /* un des joueurs n'a pas son temps à 0 : la partie continue*/
	    if(element.temps() != 0) 
		  return 0;
	  }
		/* la partie est terminée car tous les joueurs ont leurs temps à
		 * 0
		 */
	  return 1;
	}
	/**
	 * 
	 * @param o1
	 * It's an object with which one wants to compare their object.
	 * 
	 * @return boolean
	 * It returns a boolean which is "true" if the both are alike, and false otherwise.
	 */
	@Override
	public boolean equals(Object o1) {
		return o1 instanceof Partie p1 && p1.bouton == bouton && p1.temps == temps &&
				p1.part.equals(part) && pBoardSize == p1.pBoardSize;
	}
	
	/**
	 * 
	 * 
	 * @return String
	 * It returns a String which represents in a litteral way the game.
	 */
	@Override
	public String toString() {
		var bd = new StringBuilder();
		for(var elements:part){
			bd.append(elements.nom());
			bd.append("\n");
			bd.append(elements.age());
			bd.append("\n");
			bd.append("\n\n\n\n\n");
		}
		return "Cette partie donne initialement : "+temps+" de temps à ses joueurs, leurs plateaux sont de taille "+pBoardSize
				+", ils ont "+bouton+" boutons au début de la partie, et les participants sont : \n\n\n "+bd;
	}
	
	/**
	 * 
	 * 
	 * @return int
	 * It returns a int which represents the hashCode of a party.
	 */
	@Override
	public int hashCode() {
		return Integer.hashCode(bouton)^Integer.hashCode(temps)^Integer.hashCode(pBoardSize);
	}
	public static void main(String[] args) {
		var part1 = new Partie();
		
		/* on relance la partie indéfiniment tant qu'elle n'est pas finie*/
		
		while(part1.finDePartie() != 1) {
				
		}
		
	}

}
