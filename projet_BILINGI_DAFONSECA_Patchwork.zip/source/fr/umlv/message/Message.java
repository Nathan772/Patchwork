package fr.umlv.message;

public class Message {
	
	public static void messageAccueil() {
		
		System.out.println("Bonjour vous venez de démarrez une partie de Patchwork.");
		System.out.println("Voulez-vous jouer entre deux humains ou contre une IA ? : ");
	}

}
