package fr.umlv.outils;

import java.util.Objects;

public class Point {
	private int x;
	private int y;
	public Point(int x1, int y1){
	  if(x1 < 0 || x1 > 20) {
		  throw new IllegalArgumentException
		  ("Lookout your coordinate 'x' must be between 0 and 20");
	  }
	  if(y1 < 0 || y1 > 20) {
		  throw new IllegalArgumentException
		  ("Lookout your coordinate 'y' must be between 0 and 20");
	  }
	  x = x1;
	  y = y1;
	}
	
	@Override
	/**
	 * Thiss method enables to compare two points, in order to know if they're equals or not.
	 * @param o
	 * it represents an object with which one wants to compare their points.
	 * 
	 * @return boolean
	 * it indicates either two points are equals or not.
	 * 1 means equals.
	 * 0 means different.
	 */
	public boolean equals(Object o1) {
		Objects.requireNonNull(o1,"You cannot compare a point with an null object");
		return o1 instanceof Point p1 && (p1.x == x) && (p1.y == y);
		
	}
	/**
	 * This method express with words a point coordinates
	 * @return String
	 * it is a litteral representation of a point
	 */
	@Override
	public String toString(){
		return "Your point coordinate are [x = "+x+", y= " +y+"]";
	}
	
	@Override
	/**
	 * This method represents a point hashcode
	 * @return int
	 * the return value is an int which is the item hashCode.
	 */
	public int hashCode(){
		return Integer.hashCode(x)^Integer.hashCode(y);
	}
	
	/* this method enable to update the cordinate "X" of
	 * an element
	 */
	public void updateX(int x1) {
		if(x1 < 0 || x1 > 20) {
			  throw new IllegalArgumentException
			  ("Lookout your coordinate 'x' must be between 0 and 20");
		  }
		x = x1;
	}
	
	/* this method enable to update the cordinate "Y" of
	 * an element
	 */
	public void updateY(int y1) {
		  if(y1 < 0 || y1 > 20) {
			  throw new IllegalArgumentException
			  ("Lookout your coordinate 'y' must be between 0 and 20");
		  }
		y = y1;
	}
	

}
